package com.chintech.learnspring.SpringAssignment.repos;

import com.chintech.learnspring.SpringAssignment.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
}
