package com.chintech.learnspring.SpringAssignment.controller;


import com.chintech.learnspring.SpringAssignment.entity.Customer;
import com.chintech.learnspring.SpringAssignment.repos.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CustomerController {

    @Autowired
    private CustomerRepository customerRepository;

    @RequestMapping("/")
    public String home() {
        try{
            return "Welcome to home!!!!";
        } catch (Exception ex) {
            ex.printStackTrace();
            return "Exception raised in loading home page";
        }
    }

    @RequestMapping("/customers")
    public List<Customer> getCustomers() {
        return customerRepository.findAll();
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{id}")
    public Customer getSpecificCustomer(@PathVariable("id") Integer id) {
        return customerRepository.getOne(id);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/customers")
    public void saveCustomer(@RequestBody Customer customer) {
        customerRepository.save(customer);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/{id}")
    public void deleteCustomer(@PathVariable Integer id) {
        customerRepository.deleteById(id);
    }
}
